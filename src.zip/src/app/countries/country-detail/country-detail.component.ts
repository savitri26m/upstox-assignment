import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { CountriesService } from 'src/app/services/countries.service';
import { ICountry } from 'src/app/modals/countries.model';

@Component({
  selector: 'app-country-detail',
  templateUrl: './country-detail.component.html',
  styleUrls: ['./country-detail.component.css']
})
export class CountryDetailComponent implements OnInit {

  country: ICountry;
  id: number;

  constructor(private route: ActivatedRoute, 
        private countryService: CountriesService) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.country = this.countryService.countryDetail[this.id]

  }

}
