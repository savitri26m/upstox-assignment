import { Component, OnInit, OnChanges } from '@angular/core';
import { CountriesService } from 'src/app/services/countries.service';
import { ICountry } from 'src/app/modals/countries.model';
import { Router } from '@angular/router';
import { StringMap } from '@angular/compiler/src/compiler_facade_interface';

@Component({
  selector: 'app-countries-list',
  templateUrl: './countries-list.component.html',
  styleUrls: ['./countries-list.component.css']
})
export class CountriesListComponent implements OnInit {

  countries: ICountry[];
  searchTerm: string;

  filterCountriesData: ICountry[] = [];

  filterByString: string = 'all';

  constructor(private countryService: CountriesService,
          private router: Router) {}
  
  filterCountries(filter: string){
    if(filter === this.filterByString){
      this.filterCountriesData = this.countries.slice();
    }
    else{
      this.filterByString = filter;
      this.filterCountriesData = this.countries.filter(
        data => {
          console.log(data);
          return data.region.toLocaleLowerCase() === filter;  
        }
      )
      
      console.log(this.filterCountriesData);
    }
  }

  ngOnInit(): void {
    this.countryService.getCountries().subscribe(
      allCountryData => {
        this.countries = allCountryData;
        this.filterCountriesData = this.countries.slice();
        this.countryService.countryDetail = this.filterCountriesData; 
      }
    )
  }

  displayCountry(id: number){
    this.router.navigate(['country-item', id]);
  }

}
